<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
	<style type="text/css">
		table{
			
			
		}
		
	</style>
	
</head>
<body>
	<div align="center">
	<div ><h2 style="color:indigo;font-family:'Kaushan Script',cursive;">Here Are Silent Warriors</h2></div>
	<br><br>
</div>
	<div class="row">
		<!-- First Conatiner -->
		<div class="container col-sm-3" style="background-color:pink;>
	<table>
				<tr><td colspan="2"><img src="me.jpg" style="width:70px;height:70px;"></td></tr>
                <br>
                <tr>
                	<td>Name:</td>
                	<td>KSHITIJ PATEL</td>

                </tr>
                <br>
                <tr> <td>
                	Year Of Graduuation:
                </td>
                <td>1st</td></tr>

	</table>
	<br>
	   Currently he is student of MOTILAL NEHRU NATIONAL INSTITUTE OF TECHNOLOGY
                HE is in Electrical Engineering Branch
                He is member of E-CELL MNNIT Allahabad as a Web Developer

		</div>
		<!-- Second Conatiner -->
		<div class="container col-sm-3" style="background-color:pink;">
			<table>
				<tr><td colspan="2"><img src="child.jpg" style="width:70px;height:70px;"></td></tr>
                <br>
                <tr>
                	<td>Name:</td>
                	<td>Ajay Jaiswal</td>

                </tr>
                <br>
                <tr> <td>
                	Year Of Graduuation:
                </td>
                <td>1st</td></tr>
                <br>
               

			</table>
		 Currently he is student of MOTILAL NEHRU NATIONAL INSTITUTE OF TECHNOLOGY
                HE is in Electrical Engineering Branch
                He is member of E-CELL MNNIT Allahabad as a Web Developer</div>
		<!-- Third Conatiner -->
		<div class="container col-sm-3" style="background-color:pink;>
			<table>
				<tr><td colspan="2"><img src="child.jpg" style="width:70px;height:70px;"></td></tr>
                <br>
                <tr>
                	<td>Name:</td>
                	<td>Krishna Shah</td>

                </tr>
                <br>
                <tr> <td>
                	Year Of Graduuation:
                </td>
                <td>1st</td></tr>

			</table>
			 Currently he is student of MOTILAL NEHRU NATIONAL INSTITUTE OF TECHNOLOGY
                HE is in Electrical Engineering Branch
                He is member of E-CELL MNNIT Allahabad as a Web Developer
		</div>




	</div>

</body>
</html>