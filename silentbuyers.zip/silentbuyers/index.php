<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.navspan>a{
			margin-left:20px;
			line-height:20px;
			font-size:20px;
			color:white;
			
		}
		.maindiv{
			animation:imageslider 9s infinite linear;
			height:300px;
			width:84vw;
			position:relative;
		
			margin-top:40px;
			background-image:url('img1.jpeg');
		
			
			background-repeat:no-repeat;
			background-size:cover;
			animation-delay:-1s;
		}
	
li{
	padding:9px;
	list-style-type:none;
	text-align:center;
}
/*
li:nth-child(odd){
	background-color:#fff;
}
li:nth-child(even){
	background-color:#fff;
}
/*
input{
	background-color:#fff;
}
*/
.navspan a:hover{
	text-decoration:none;
}

	</style>

	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
<!--
	<div class="container" style="margin-left:40vw;z-index:9999">
	alert message 1 
<div class="alert" style="background-color:pink;padding:20px;position:fixed;top:40px;">
	You can buy your semester books from here <span class="closebtn" onclick="this.parentElement.style.display='none'" style="cursor:pointer;color:red;margin-left:20px;">&times</span>

</div>
 alert message 2 
<div class="alert" style="background-color:pink;padding:20px;position:fixed;top:160px;">
	You can sell your old study materials to help your juniors <span class="closebtn" onclick="this.parentElement.style.display='none'" style="cursor:pointer;color:red;margin-left:20px;">&times</span>

</div>
</div> -->



 


	<div style="background-color:indigo;width:100vw;"><h3 style="text-align:center;padding:15px;color:white;font-family:'Kaushan Script',cursive;">Welcome To Silent Buyers</h3>
		<br>
		
	<span class="navspan" id="navigation"><a href="index.php">Home</a>
		<a href="aboutus.php">About Us</a>
		<a href="contactus.php">Contact Us</a>
		<a href="adminlogin.php" id="admin">Admin Login</a></span>	
	</div>
	<br>
	<marquee> Note:We will start taking responses soon after exam is over THANKYOU!     </marquee>
	<br>
	<div class="row" style="background-color:transparent;">
		<!-- First container -->
<div id="fst" class="container col-sm-4" style="height:30%;background-color:transparent;margin-top:40px;box-shadow:4px 4px 4px grey;">
	        <h3 style="text-align:center;color:#e4145b;">Fill This Please <a href="javascript:void(0)" style="float:right;color:red;" onclick="removefst()" title="Remove This form"><i>&times</i></a></h3>
	<div class="column">
			<form method="POST">
			<label>Name:</label>
			<input class="form-control" type="text" name="name" placeholder="Enter Your Name">
			<label>Enter Year Of Graduation:</label>	
			<input class="form-control" type="text" name="year" placeholder="ie 1st/2nd/3rd">
			<label>Number Of Books:</label>
			<input class="form-control" type="text" name="bookno" placeholder="Enter number of books to sell">


			<label>Contact no</label>
			<input class="form-control" type="text" name="contact" placeholder="Enter mobile number "> 
			<label>Room no,Hostal Name</label>
			<input class="form-control" type="text" name="room" placeholder="ie 525,SVBH "> <br>
			<button type="submit" class="btn btn-primary" name="submit" style="margin-bottom:10px;">SUBMIT</button>
		    </form>
	</div>
</div>
	<!-- Second container -->
	<div id="snd" class="container col-sm-4" style="height:445px;background-color:transparent;margin-top:40px;border: 4px solid white;overflow:hidden;box-shadow:4px 4px 4px grey;">
		<h3 style="text-align:center;color:#e4145b;">Important Links</h3>
		<li><a href="../sellingonline/product-catagory/books.php" style="text-shadow:5px 5px 5px grey;">Buy Your Semester Books </a></li>
		<li><a href="#" style="text-shadow:5px 5px 5px grey;"> Sell your old books to help your juniors </a></li>
		<li><a href="../sellingonline/admin_regist.php" style="text-shadow:5px 5px 5px grey;">Apply to  be an Admin</a></li>
		<li><a href="#" style="text-shadow:5px 5px 5px grey;"> Our Terms And Conditions </a></li>
		
    </div>

	
		


</div>
<center>
<!--<div class="maindiv" align="center"></div>  -->
<footer style="background-color:brown;width:85vw;">
	
<div style="display:flex;flex-direction:row;justify-content:space-around;margin-top:50px;"> 
<div><figure style="margin-top:50px;">
  <a href="../sellingonline/product-catagory/mall.php"><img src="mall.jpg" alt="Trulli" style="width:50px;height:50px;">
  <figcaption align="center" style="color:white">
  	Shopping Mall
  </figcaption>
</a>
</figure></div>
<div><figure style="margin-top: 50px;">
 <a href="../sellingonline/admin_regist.php"> <img src="child.jpg" alt="Trulli" style="width:50px;height:50px;"></a>
  <figcaption align="center" style="color:white">
  	Be An Admin
  </figcaption>
</figure></div>
<div><figure style="margin-top: 50px;">
  <a href="onlinelrn.php"><img src="book.jpg" alt="Trulli" style="width:50px;height:50px;">
  <figcaption align="center" style="color:white">
  	Study Forum
  </figcaption>
</a>
</figure></div>
<div></div>

  </div>
  
  	<h3 style="color:white">How To Be An Admin</h3>
  	<p style="color:white;">
     To be an admin you have to register with us<br>
     You should qualify all the criteria decided by our team<br>
     please read our <a href="#"></a> term and conditions</a>
     
  </p>

</footer>
</center>
<script type="text/javascript">
	function removefst(){
	document.getElementById("fst").style.display='none';
}
</script>


</body>
</html>
<script>
	console.log(screen.height);
	var admin=document.getElementById('admin');
	if (screen.height<600) {
		admin.style.display='none';
	}
	var height=document.getElementById('fst').style.height;
	console.log(height);
	var height2=document.getElementById('snd').style.height;
	console.log(height2);
</script>
<?php

//connection with database

$conn=mysqli_connect("localhost","root","","silent");
  // if($conn==true)
   //	echo "connected";
   if(isset($_REQUEST['submit']))//check is button is clicked or not
 {
 	
 	$name=$_REQUEST["name"];
$year=$_REQUEST['year'];
$bookno=$_REQUEST['bookno'];
$contact=$_REQUEST['contact'];
$room=$_REQUEST['room'];
   $qry="INSERT INTO `buyers`( `name`, `year(graduation)`, `books_number`, `contact no`,`Room/Hostal`) VALUES
    ('$name','$year',$bookno,'$contact','$room')";
   //run query
   $runn=mysqli_query($conn,$qry);
   if(isset($_REQUEST['submit']))
   {
     ?>
     <script type="text/javascript">
     alert("THANKS WE WILL CONTACT YOU SOON");
     window.open('index.php','_self');
     </script>
     <?php
   }
   else{
   	?>
   	<script type="text/javascript">
   		alert("please try again");
   		location.href("silentbuyers/index.php");
   	</script>
   	<?php
   }
 }

?>
