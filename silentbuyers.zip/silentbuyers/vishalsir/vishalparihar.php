<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.div1>div{
			font-size:20px;
			box-shadow:10px 20px 10px grey;
			text-align:center;
			background-color:#ffffff;
			padding:20px;
		}
		.div1>div>a:hover{
			color:red;
		}
	</style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
<h2 style="text-align:center;color:indigo;font-family:'Kaushan Script',cursive;">Vishal Sir </h2>

<div class="container">
	<div style="display:flex;flex-direction:row;" ><a href="vishalsirlogin.php" style="color:white;background-color:green;border-radius:5px;font-size:20px;margin-left:25px"> Admin Login </a>
<a href="../../sellingonline/admin_regist.php" style="color:white;background-color:green;border-radius:5px; font-size:20px;margin-left:25px">Be An Admin </a> </div>

	<div class="div1" style="display:flex;flex-direction:column;justify-content:space-around;"> 

	<div><a href="#">Daily Vocabbular</a></div>
	<br>
	<div> <a href="studentlist.php">Daily Quiz</a></div>
	 <br>
	<div> <a href="#">Daily News Paper </a></div>
	 <br>
	 <div><a href="#"> Change Password </a></div>
	 <br>
	<div> <a href="adminlogin.php"> Logout </a></div>
</div>
</div>
</body>
</html>