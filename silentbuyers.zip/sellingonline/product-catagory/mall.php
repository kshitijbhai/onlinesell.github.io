<!DOCTYPE html>
<html>
<head>
  <title>mall</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
 
.links a{
  color:white;
  padding:12px;
  font-size:20px;
  text-decoration:none;
}
.links a:hover{
  
  color:black;
  text-decoration:none;
}
.icon{
  color:white;
  display:none;
}
.links{
  display:flex;
  flex-direction:row;
  justify-content:space-around;
}

 @media screen and (max-width:600px)
  {
    .responsive
    {
  display:flex;
  flex-direction:column;
  justify-content:space-around;
  position:absolute;
  top:60px;
  left:40px;
  

}
.responsive a{
  text-decoration:none;
  font-size:23px;
  background-color:#333;
  box-shadow:5px 5px 5px grey;
  color:white;
  margin-top:12px;
transition: all 1s;
text-align:center;
padding:6px;
}
.responsive a:hover{
  color:#f2f2f2;
  text-decoration:none;

}

.icon
{
  display:flex;
  position: absolute;
  top:20px;
  left:40px;
  color:white;

  }
  .links>a{
    display:none;
  }
}
</style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>

  <nav style="display:flex;flex-direction:row;justify-content:space-between;background-color:#194458;" class="nav" >
    <div style="font-family:'Kaushan Script',cursive;color:white;font-weight:900;width:50px;height:50px;margin-left:120px;">
      Our Adda
    </div>
  <div>
    <a href="javascript:void(0)" class="icon" onclick="mynav()">
      <i class="fa fa-bars"> </i></a>
  </div>
<div class="links" id="topnav">
 
 <a href="#">Login</a>
  <a href="#">Sign up</a>
   <a href="#" class="catagory" onclick="showcatagory()">Catagory</a>
   <a href="../admin_index.php">Admin Login</a>

  
</div>
</nav>
<script type="text/javascript">
  function mynav(){
  var x=document.getElementById('topnav');
  if(x.className=="links"){
x.className="responsive";
  }
  else
  {
x.className="links";
  }

}
</script>
</body>
</html>