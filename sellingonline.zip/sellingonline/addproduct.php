<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
  <div class="container col-sm-4" style="border:4px solid pink">
  	<form action="" method="POST" enctype="multipart/form-data">
  		<div class="form-group">
  			<label>Product name</label>
  			<input type="text" name="productname" class="form-control">
  		</div>
  		<div class="form-group">
  			<label>Product descount</label>
  			<input type="text" name="descount" class="form-control">
  		</div>

<div class="form-group">
  			<label>Product quantity</label>
  			<input type="text" name="qty" class="form-control">
  		</div>

<div class="form-group">
  			<label>Product cost</label>
  			<input type="text" name="cost" class="form-control">
  		</div>

<div class="form-group">
  			<label>Product price</label>
  			<input type="text" name="price" class="form-control">
  		</div>
  		<div class="form-group">
  			<label>Choose Catagory</label>
  			<select name="catagory">
  				<option id="books">Books</option>
  				<option id="casio">Casio</option>
  				<option id="calculator">Calculator</option>
  			</select>
  		</div>
         <label for="img1">Picture 1 (Front View):</label>
           <div class="input-group">
          <input type="file" class="form-control" id="img1" name="img1">  
          </div>
           <label for="img2">Picture 2 (Side View):</label>
           <div class="input-group">
           <input type="file" class="form-control" id="img2" name="img2" >  
            </div>
             <label for="img3">Picture 3 (Specifications):</label>
              <div class="input-group">
           <input type="file" class="form-control" id="img3" name="img3">  
               </div>

           <input type="submit" name="addproduct" class="btn btn-primary" style="margin-top:20px;margin-left:30px;">
  	</form>
  	<div ></div>

  </div>
</body>
</html>

<?php
//connection with database
include('dbconn.php');

if (isset($_POST['addproduct'])) {

$productname=$_REQUEST['productname'];
$descount=$_REQUEST['descount'];
$qty=$_REQUEST['qty'];
$cost=$_REQUEST['cost'];
$price=$_REQUEST['price'];

$catagory=$_REQUEST['catagory'];


if(isset($_FILES['img1']))
{
move_uploaded_file($_FILES["img1"]["tmp_name"],"productimages/".$_FILES['img1']['name']);
$img1=$_FILES["img1"]["name"];
}
else
echo "file not uploaded";
if(isset($_FILES['img2']))
{
move_uploaded_file($_FILES['img2']['tmp_name'],"productimages/".$_FILES['img2']['name']);
$img2=$_FILES['img2']["name"];
}
if(isset($_FILES['img1']))
{
move_uploaded_file($_FILES['img3']['tmp_name'],"productimages/".$_FILES['img3']['name']);
$img3=$_FILES['img3']["name"];
}
$query="INSERT INTO `product`( `prod_name`, `prod_desc`, `prod_qty`, `prod_cost`, `prod_price`, `catagory`, `pic1`, `pic2`, `pic3`) VALUES ('$productname','$descount','$qty','$cost','$price','$catagory','$img1','$img2','$img3')";
$run=mysqli_query($conn,$query);
if($run=true)
{
	?>
	<script type="text/javascript">
	alert("data added succsessfully")
</script>
	<?php
}
}




?>