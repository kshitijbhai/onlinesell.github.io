<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div align="center">
	<div ><h2 style="background-color:#b33d51;padding:30px; color:white;">Admin Application Form</h2></div>
	<br><br>
	<div>
		
		<p style="text-align:center;color:red;">Note :(*) added input are necessary to be filled</p>

		<form method="POST" action="" enctype="multipart/form-data" style="overflow:auto;">
		First Name: <input type="text" name="fname" max="13" required><span style="color:red">*</span><br><br><br>
		Last Name: <input type="text" name="lname" max="13" required><span style="color:red">*</span><br><br><br>
		 college name:<input type="text" name="college" required><span style="color:red">*</span><br><br><br>
		address: <input type="text" name="address" ><span style="color:red">*</span><br><br><br>
		Email: <input type="text" name="email" required><span style="color:red">*</span><br><br><br>
		username: <input type="text" name="username" required><span style="color:red">*</span><br><br><br>
password: <input type="password" name="password" max="13" required><span style="color:red">*</span><br><br><br>
 Upload Image:<input type="file" name="image">
 <br><br><br>
 <input type="submit" name="submit" value="apply" style="border:none;background-color:green;color:white;font-weight:bold;padding:5px;cursor:pointer;border-radius:3px;font-size:19px;">
</form>
	</div>
</div>
</body>
</html>
<?php
include("dbconn.php");
if (isset($_POST['submit'])) {

$fname=$_REQUEST['fname'];
$lname=$_REQUEST['lname'];
$college=$_REQUEST['college'];
$address=$_REQUEST['address'];
$uname=$_REQUEST['username'];

$password=$_REQUEST['password'];


if(isset($_FILES['image']))
{
move_uploaded_file($_FILES["image"]["tmp_name"],"adminimages/".$_FILES['image']['name']);
$image=$_FILES["image"]["name"];
}
else
echo "file not uploaded";
$query="INSERT INTO `admin`(`firstname`, `lastname`, `email`, `username`, `password`, `college`, `address`, `image`) VALUES ('$fname','$lname','$email','$uname','$password','$college','$address','$image')";
$run=mysqli_query($conn,$query);

if($run=true)
{
	?>
	<script type="text/javascript">
	alert("registration successfull");
</script>
	<?php
}
}

?>