<?php
$conn=mysqli_connect("localhost","root","","electricks");
if(mysqli_connect_errno())
{
echo "failed to connect with database";
}

?>